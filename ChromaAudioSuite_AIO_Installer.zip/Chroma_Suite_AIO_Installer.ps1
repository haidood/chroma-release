﻿<#
.SYNOPSIS
  Chroma Audio Suite v2026 - All-In-One Installer & Serial Key Activator
  Works 100% offline from extracted ZIP (VST2_x64 / VST3_x64) OR online via CI/CD.
#>
param(
    [switch]$Headless,
    [switch]$NoElevate,
    [switch]$SkipIniSave,
    [switch]$PullOnline,
    [string]$Serial = '',
    [string]$Vst2Dir = '',
    [string]$Vst3Dir = '',
    [string]$LicenseDir = '',
    [string]$SourceDir = '',
    [string]$PluginsFilter = ''
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if (-not $SourceDir) {
    $SourceDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
}

# Self-elevate in interactive GUI mode so Program Files / VST folders are writable
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin -and -not $NoElevate -and -not $Headless) {
    $argList = @('-STA', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$PSCommandPath`"")
    if ($Serial)  { $argList += @('-Serial', "`"$Serial`"") }
    if ($Vst2Dir) { $argList += @('-Vst2Dir', "`"$Vst2Dir`"") }
    if ($Vst3Dir) { $argList += @('-Vst3Dir', "`"$Vst3Dir`"") }
    Start-Process powershell -Verb RunAs -ArgumentList $argList
    return
}

# ---------------------------------------------------------------------------
# Native C# License & Hardware ID Bridge (exact match to ChromaLicenseShield.h)
# ---------------------------------------------------------------------------
$csharpBridge = @'
using System;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;

public static class ChromaLicBridge
{
    [DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
    private static extern bool GetComputerNameA(StringBuilder lpBuffer, ref uint nSize);

    [DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
    private static extern bool GetVolumeInformationA(
        string lpRootPathName, StringBuilder lpVolumeNameBuffer, uint nVolumeNameSize,
        out uint lpVolumeSerialNumber, out uint lpMaximumComponentLength,
        out uint lpFileSystemFlags, StringBuilder lpFileSystemNameBuffer, uint nFileSystemNameSize);

    private static readonly ulong[] ActiveBetaHashes = new ulong[] {
        0x2E3A53A0875BF73EUL, 0x28375AD3B493BA00UL, 0xD7B2A3386CC5058BUL, 0x40D0D96FA859B4BBUL,
        0x55B07883B31FBEE0UL, 0x526A55D43593C2B4UL, 0x62E3F27C90A0DB3BUL, 0x18FF55E691F909D7UL,
        0x5AD8E36A9AEC39D4UL, 0xDC95F117212BED00UL, 0x720FF5744D9AFE94UL, 0xC3B33838DE7DC191UL,
        0x7F51E274F0666C97UL, 0xC3D961D72BA9FE4DUL, 0x2A9FA75727992531UL, 0x13D52A775952745AUL,
        0xC2A25A2D19639E63UL, 0x022890328C76F7CCUL, 0x39075946303BCAB2UL, 0xF5E0986830A39D0AUL
    };

    private static readonly byte[] MaskTable = new byte[] { 0x5A, 0xC3, 0x89, 0xE7, 0x1F, 0x9B, 0x4D, 0x72 };
    private const ulong BetaDurationSeconds = 30UL * 24UL * 3600UL;

    public static string GetMachineHwid()
    {
        StringBuilder comp = new StringBuilder(260);
        uint sz = 256;
        GetComputerNameA(comp, ref sz);
        uint vol = 0, maxComp = 0, flags = 0;
        GetVolumeInformationA("C:\\", null, 0, out vol, out maxComp, out flags, null, 0);
        string pc = comp.Length > 0 ? comp.ToString() : "PC";
        return string.Format("{0}-{1:X8}", pc, vol);
    }

    public static string NormalizeKey(string raw)
    {
        if (string.IsNullOrEmpty(raw)) return "";
        StringBuilder mapped = new StringBuilder(raw.Length);
        foreach (char c in raw)
        {
            int uc = (int)c;
            if (uc == 0x2010 || uc == 0x2011 || uc == 0x2012 || uc == 0x2013 ||
                uc == 0x2014 || uc == 0x2015 || uc == 0x2212 || uc == 0xFE58 ||
                uc == 0xFE63 || uc == 0xFF0D || uc == 0x0096 || uc == 0x0097 || c == '-')
            {
                mapped.Append('-');
            }
            else if (c >= 'a' && c <= 'z')
            {
                mapped.Append((char)(c - 'a' + 'A'));
            }
            else if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
            {
                mapped.Append(c);
            }
            else if (c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == ',' || c == ':' || c == ';' || c == '=' || c == '|' || uc == 0x00A0)
            {
                mapped.Append(' ');
            }
        }
        string mStr = mapped.ToString();
        string chosen = mStr;
        int pos = mStr.IndexOf("CHRM", StringComparison.Ordinal);
        if (pos >= 0)
        {
            string tail = mStr.Substring(pos);
            StringBuilder compact = new StringBuilder();
            foreach (char c in tail)
            {
                if (c != ' ' && c != '-') compact.Append(c);
                else if (c == ' ' && compact.Length >= 20) break;
            }
            string cs = compact.ToString();
            if (cs.Length == 20 && cs.StartsWith("CHRM", StringComparison.Ordinal))
            {
                return cs.Substring(0, 4) + "-" + cs.Substring(4, 4) + "-" +
                       cs.Substring(8, 4) + "-" + cs.Substring(12, 4) + "-" + cs.Substring(16, 4);
            }
            StringBuilder tok = new StringBuilder();
            foreach (char c in tail)
            {
                if (c == ' ') { if (tok.Length > 0) break; }
                else tok.Append(c);
            }
            if (tok.Length > 0) chosen = tok.ToString();
        }
        StringBuilder clean = new StringBuilder(chosen.Length);
        foreach (char c in chosen) if (c != ' ') clean.Append(c);
        return clean.ToString();
    }

    public static ulong HashKey(string str)
    {
        ulong hash = 0xcbf29ce484222325UL;
        byte[] bytes = Encoding.ASCII.GetBytes(str);
        foreach (byte b in bytes)
        {
            hash ^= b;
            hash *= 0x100000001b3UL;
        }
        return hash;
    }

    public static bool IsValidActiveKey(string rawKey, out string cleanKey)
    {
        cleanKey = NormalizeKey(rawKey);
        if (string.IsNullOrEmpty(cleanKey)) return false;
        ulong h = HashKey(cleanKey);
        for (int i = 0; i < ActiveBetaHashes.Length; i++)
        {
            if (ActiveBetaHashes[i] == h) return true;
        }
        return false;
    }

    private static uint ComputeChecksum(byte[] blob, int payloadLen)
    {
        uint sum = 0x55AA55AAu;
        for (int i = 0; i < payloadLen; i++)
        {
            sum = ((sum << 5) | (sum >> 27));
            sum ^= blob[i];
        }
        return sum;
    }

    private static void Transform(byte[] data, string salt, bool encrypt)
    {
        byte[] saltBytes = Encoding.ASCII.GetBytes(string.IsNullOrEmpty(salt) ? "PC" : salt);
        for (int i = 0; i < data.Length; i++)
        {
            byte k = saltBytes[i % saltBytes.Length];
            byte m = MaskTable[i % 8];
            if (encrypt)
                data[i] = (byte)(((data[i] ^ k ^ m) + (i & 0xFF)) & 0xFF);
            else
            {
                byte sub = (byte)((data[i] - (i & 0xFF)) & 0xFF);
                data[i] = (byte)(sub ^ m ^ k);
            }
        }
    }

    public static string ReadLicenseStatus(string licPath, out bool isValid, out int daysLeft, out string keyMasked)
    {
        isValid = false;
        daysLeft = 0;
        keyMasked = "";
        if (!File.Exists(licPath)) return "No local license found.";
        try
        {
            byte[] blob = File.ReadAllBytes(licPath);
            if (blob.Length != 188) return "Legacy or unreadable license format.";
            string hwid = GetMachineHwid();
            Transform(blob, hwid, false);
            string magic = Encoding.ASCII.GetString(blob, 0, 8);
            if (magic != "CHROMA_L") return "License bound to different machine or corrupted.";
            uint storedCrc = BitConverter.ToUInt32(blob, 184);
            if (storedCrc != ComputeChecksum(blob, 184)) return "License integrity check failed.";

            string blobHwid = Encoding.ASCII.GetString(blob, 72, 64).TrimEnd('\0');
            if (blobHwid != hwid) return "Machine HWID mismatch.";

            string keyRaw = Encoding.ASCII.GetString(blob, 8, 64).TrimEnd('\0');
            string normKey;
            if (!IsValidActiveKey(keyRaw, out normKey)) return "Stored beta key is retired.";

            ulong actTime = BitConverter.ToUInt64(blob, 168);
            ulong expTime = BitConverter.ToUInt64(blob, 176);
            ulong now = (ulong)DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            if (actTime == 0 || expTime == 0 || expTime > actTime + BetaDurationSeconds || now >= expTime)
                return "Beta license expired (30 days elapsed).";

            isValid = true;
            daysLeft = (int)((expTime - now + 86399UL) / 86400UL);
            keyMasked = normKey.Length >= 9 ? normKey.Substring(0, 9) + "-****-****" : normKey;
            return string.Format("ACTIVE ({0}d left | {1})", daysLeft, keyMasked);
        }
        catch (Exception ex)
        {
            return "License read error: " + ex.Message;
        }
    }

    public static int QueryServerOptional(string key, string hwid)
    {
        try
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:7860/api/license/verify");
            req.Method = "POST";
            req.ContentType = "application/json";
            req.Timeout = 450;
            req.ReadWriteTimeout = 450;
            string body = "{\"key\":\"" + key + "\",\"hwid\":\"" + hwid + "\"}";
            byte[] payload = Encoding.UTF8.GetBytes(body);
            req.ContentLength = payload.Length;
            using (Stream s = req.GetRequestStream()) s.Write(payload, 0, payload.Length);
            using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
            {
                string txt = sr.ReadToEnd();
                if (txt.Contains("\"valid\":true")) return 1;
                if (txt.Contains("\"reason\":\"expired\"")) return -2;
                if (txt.Contains("\"valid\":false")) return -1;
            }
        }
        catch { }
        return 0; // offline or local server unreachable -> allow offline activation via verified hash
    }

    public static bool SaveLicense(string licPath, string rawKey, out string message)
    {
        string cleanKey;
        if (!IsValidActiveKey(rawKey, out cleanKey))
        {
            message = "Invalid or retired serial key. Please check the 20-character key (CHRM-XXXX-XXXX-XXXX-XXXX).";
            return false;
        }
        string hwid = GetMachineHwid();
        int srv = QueryServerOptional(cleanKey, hwid);
        if (srv == -1 || srv == -2)
        {
            message = "This beta key has expired or been revoked by server policy.";
            return false;
        }

        byte[] blob = new byte[188]; // 8 + 64 + 64 + 32 + 8 + 8 + 4 = 188 bytes packed
        Encoding.ASCII.GetBytes("CHROMA_L").CopyTo(blob, 0);
        byte[] kb = Encoding.ASCII.GetBytes(cleanKey);
        Array.Copy(kb, 0, blob, 8, Math.Min(63, kb.Length));
        byte[] hb = Encoding.ASCII.GetBytes(hwid);
        Array.Copy(hb, 0, blob, 72, Math.Min(63, hb.Length));
        byte[] tb = Encoding.ASCII.GetBytes("BETA_30D");
        Array.Copy(tb, 0, blob, 136, Math.Min(31, tb.Length));

        ulong now = (ulong)DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        ulong exp = now + BetaDurationSeconds;
        BitConverter.GetBytes(now).CopyTo(blob, 168);
        BitConverter.GetBytes(exp).CopyTo(blob, 176);
        uint crc = ComputeChecksum(blob, 184);
        BitConverter.GetBytes(crc).CopyTo(blob, 184);

        Transform(blob, hwid, true);
        Directory.CreateDirectory(Path.GetDirectoryName(licPath));
        File.WriteAllBytes(licPath, blob);
        message = string.Format("Activated! Hardware-locked 30-day license saved for {0}.", hwid);
        return true;
    }
}
'@

if (-not ([System.Management.Automation.PSTypeName]'ChromaLicBridge').Type) {
    Add-Type -TypeDefinition $csharpBridge -Language CSharp
}

# ---------------------------------------------------------------------------
# Paths, INI Config & Plugin Definitions (All 15 Plugins)
# ---------------------------------------------------------------------------
$RepoRootRaw = 'https://raw.githubusercontent.com/haidood/chroma-release/main'
$RepoRawBase = "$RepoRootRaw/precompiled"
$CacheBust = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()

$chromaAppDir = Join-Path $env:APPDATA 'ChromaAudio'
$iniPath = Join-Path $chromaAppDir 'settings.ini'
$defaultLicPath = Join-Path (Join-Path $chromaAppDir 'Licenses') 'license.dat'
$activeLicPath = if ($LicenseDir) { Join-Path $LicenseDir 'license.dat' } else { $defaultLicPath }

function Get-IniSetting([string]$key, [string]$defaultVal) {
    if (Test-Path $iniPath) {
        foreach ($line in Get-Content $iniPath -ErrorAction SilentlyContinue) {
            if ($line -match "^\s*$key\s*=\s*(.+)$") {
                $val = $matches[1].Trim().TrimEnd('\', '/')
                if ($val -like '*\Dev') { $val = $val.Substring(0, $val.Length - 4) }
                if ($val) { return $val }
            }
        }
    }
    return $defaultVal
}

function Set-IniSetting([string]$section, [string]$key, [string]$val) {
    New-Item -ItemType Directory -Force -Path $chromaAppDir | Out-Null
    $lines = New-Object 'System.Collections.Generic.List[string]'
    if (Test-Path $iniPath) {
        foreach ($rawLine in @(Get-Content $iniPath -ErrorAction SilentlyContinue)) {
            if ($null -ne $rawLine) { [void]$lines.Add([string]$rawLine) }
        }
    }
    $inSec = $false; $secIdx = -1; $found = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $t = $lines[$i].Trim()
        if ($t -match '^\[(.+)\]$') {
            $inSec = ($matches[1] -ieq $section)
            if ($inSec) { $secIdx = $i }
        } elseif ($inSec -and $t -match "^\s*$key\s*=") {
            $lines[$i] = "$key=$val"
            $found = $true
            break
        }
    }
    if (-not $found) {
        if ($secIdx -lt 0) {
            [void]$lines.Add("[$section]")
            [void]$lines.Add("$key=$val")
        } else {
            $lines.Insert($secIdx + 1, "$key=$val")
        }
    }
    Set-Content -Path $iniPath -Value $lines.ToArray() -Encoding ASCII
}

$Plugins = @(
    @{ bin='ChromaCoreVST';         key='ChromaCore';            cat='Synthesizer' },
    @{ bin='ChromaPulse';           key='ChromaPulse';           cat='Drum Workstation' },
    @{ bin='ChromaDeep';            key='ChromaDeep';            cat='Synth / Additive' },
    @{ bin='ChromaMaster';          key='ChromaMaster';          cat='Mastering Suite' },
    @{ bin='ChromaVoice';           key='ChromaVoice';           cat='Vocal Processor' },
    @{ bin='ChromaComp';            key='ChromaComp';            cat='Dynamics' },
    @{ bin='ChromaDelay';           key='ChromaDelay';           cat='Time / Space' },
    @{ bin='ChromaVerb';            key='ChromaVerb';            cat='Reverb' },
    @{ bin='ChromaScramble';        key='ChromaScramble';        cat='Glitch / Mod' },
    @{ bin='ChromaWidener';         key='ChromaWidener';         cat='Stereo Width' },
    @{ bin='ChromaSlice';           key='ChromaSlice';           cat='Granular Slice' },
    @{ bin='ChromaTransientShaper'; key='ChromaTransientShaper'; cat='Transients' },
    @{ bin='ChromaDesigner';        key='ChromaDesigner';        cat='500-Series Eq/Dyn' },
    @{ bin='ChromaFhaser';          key='ChromaFhaser';          cat='Phaser' },
    @{ bin='ChromaX';               key='ChromaX';               cat='Multi-FX' }
)

# Detect existing installs across saved INI, registry, and standard VST locations
$savedVst2 = Get-IniSetting 'VstDir' ''
$savedVst3 = Get-IniSetting 'Vst3Dir' ''
$regVst2 = ''
try {
    $regVal = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\VST' -Name 'VSTPluginsPath' -ErrorAction SilentlyContinue).VSTPluginsPath
    if ($regVal) { $regVst2 = $regVal.Trim().TrimEnd('\', '/') }
} catch {}

$probeVst2 = @($savedVst2, $regVst2, 'C:\Program Files\VstPlugins', 'C:\Program Files\Steinberg\VstPlugins', 'C:\Program Files\Common Files\VST2') |
    Where-Object { $_ } | Select-Object -Unique
$detectedVst2 = ''
foreach ($cand in $probeVst2) {
    if ((Test-Path $cand) -and ((Get-ChildItem $cand -Filter 'Chroma*.dll' -ErrorAction SilentlyContinue).Count -gt 0)) {
        $detectedVst2 = $cand
        break
    }
}

$initVst2 = if ($Vst2Dir) { $Vst2Dir } elseif ($savedVst2) { $savedVst2 } elseif ($detectedVst2) { $detectedVst2 } elseif ($regVst2) { $regVst2 } else { 'C:\Program Files\VstPlugins' }
$initVst3 = if ($Vst3Dir) { $Vst3Dir } elseif ($savedVst3) { $savedVst3 } else { 'C:\Program Files\Common Files\VST3' }

# Local ZIP offline payload detection
$localVst2Src = Join-Path $SourceDir 'VST2_x64'
$localVst3Src = Join-Path $SourceDir 'VST3_x64'
$hasLocalZipPayload = (Test-Path $localVst2Src) -and (Test-Path $localVst3Src)

# Load manifest (local ZIP copy first, optional CI/CD fallback)
$manifest = $null
$localManPath = Join-Path $SourceDir 'version_manifest.json'
if (Test-Path $localManPath) {
    try { $manifest = Get-Content $localManPath -Raw | ConvertFrom-Json } catch {}
}
if (-not $manifest -or $PullOnline) {
    try {
        $wcTmp = New-Object System.Net.WebClient
        $manifest = ($wcTmp.DownloadString("$RepoRootRaw/version_manifest.json?t=$CacheBust")) | ConvertFrom-Json
    } catch {}
}

function Get-LegacyDetectionSummary([string]$v2Dir, [string]$v3Dir) {
    $notes = New-Object 'System.Collections.Generic.List[string]'
    $installedCount = 0
    foreach ($p in $Plugins) {
        $has2 = Test-Path (Join-Path $v2Dir "$($p.bin).dll")
        $has3 = Test-Path (Join-Path $v3Dir "$($p.bin).vst3")
        if ($has2 -or $has3) { $installedCount++ }
    }
    if ($installedCount -gt 0) { [void]$notes.Add("$installedCount/15 plugins detected in target folders") }
    else { [void]$notes.Add("Fresh install (0/15 existing in target folders)") }

    if (Test-Path (Join-Path $v2Dir 'Dev')) { [void]$notes.Add('Legacy \Dev folder detected (will auto-migrate)') }
    if ((Test-Path (Join-Path $v2Dir 'ChromaCorePro.dll')) -or (Test-Path (Join-Path $v3Dir 'ChromaCorePro.vst3'))) {
        [void]$notes.Add('Legacy ChromaCorePro detected (will upgrade -> ChromaCoreVST)')
    }
    $x64Sub = Join-Path $v2Dir 'x64'
    if ((Test-Path $x64Sub) -and ((Get-ChildItem $x64Sub -Filter 'Chroma*.dll' -ErrorAction SilentlyContinue).Count -gt 0)) {
        [void]$notes.Add('Duplicate \x64 plugins detected (will clean)')
    }
    return ($notes -join '  •  ')
}

function Perform-Install(
    [string]$dstVst2,
    [string]$dstVst3,
    [array]$selectedBins,
    [bool]$forceOnline,
    [scriptblock]$onProgress
) {
    New-Item -ItemType Directory -Force -Path $dstVst2 | Out-Null
    New-Item -ItemType Directory -Force -Path $dstVst3 | Out-Null

    if (-not $SkipIniSave) {
        Set-IniSetting 'Updates' 'VstDir' $dstVst2
        Set-IniSetting 'Updates' 'Vst3Dir' $dstVst3
    }

    # Migrate legacy VstPlugins\Dev (only when targeting standard or existing folder)
    $legacyDev = Join-Path $dstVst2 'Dev'
    if (Test-Path $legacyDev) {
        & $onProgress 2 "Migrating legacy Dev subfolder..."
        Get-ChildItem $legacyDev -File -ErrorAction SilentlyContinue | ForEach-Object {
            $ext = $_.Extension.ToLower()
            if ($ext -eq '.dll') {
                $dst = Join-Path $dstVst2 $_.Name
                if (-not (Test-Path $dst)) { Move-Item $_.FullName $dst -Force -ErrorAction SilentlyContinue }
                else { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
            } elseif ($ext -eq '.vst3') {
                $dst = Join-Path $dstVst3 $_.Name
                if (-not (Test-Path $dst)) { Move-Item $_.FullName $dst -Force -ErrorAction SilentlyContinue }
                else { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
            } else {
                Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
            }
        }
        Remove-Item $legacyDev -Recurse -Force -ErrorAction SilentlyContinue
    }

    # Clean legacy ChromaCorePro, stale nested x64 duplicates, and old .vst3 copies from VST2/VST3 folders
    $nestedX64 = Join-Path $dstVst2 'x64'
    $subChroma2 = Join-Path $dstVst2 'Chroma'
    $subChroma3 = Join-Path $dstVst3 'Chroma'
    foreach ($d in @($dstVst2, $dstVst3, $nestedX64, $subChroma2, $subChroma3)) {
        if (Test-Path $d) { Remove-Item (Join-Path $d 'ChromaCorePro.*') -Force -ErrorAction SilentlyContinue }
    }
    if (Test-Path $nestedX64) {
        Remove-Item (Join-Path $nestedX64 'Chroma*.dll') -Force -ErrorAction SilentlyContinue
        Remove-Item (Join-Path $nestedX64 'Chroma*.vst3') -Force -ErrorAction SilentlyContinue
    }
    # Remove old .vst3 copies from target VST2/VST3 folders and Chroma subfolders before laying down fresh files
    foreach ($v3CleanDir in @($dstVst2, $dstVst3, $subChroma2, $subChroma3)) {
        if (Test-Path $v3CleanDir) {
            Remove-Item (Join-Path $v3CleanDir 'Chroma*.vst3') -Force -ErrorAction SilentlyContinue
        }
    }
    if (-not $SkipIniSave) {
        foreach ($sysV3Dir in @(
            'C:\Program Files\Common Files\VST3',
            'C:\Program Files\Common Files\VST3\Chroma',
            'C:\VST_Plugins64',
            'C:\VST_Plugins64\Chroma',
            'C:\VST_Plugins\Chroma'
        )) {
            if (Test-Path $sysV3Dir) {
                Remove-Item (Join-Path $sysV3Dir 'Chroma*.vst3') -Force -ErrorAction SilentlyContinue
            }
        }
    }

    $wc = $null
    if ($forceOnline -or -not $hasLocalZipPayload) {
        $wc = New-Object System.Net.WebClient
    }

    $installFile = {
        param([string]$fileName, [string]$localFolder, [string]$destFolder, [bool]$optional)
        $dstFile = Join-Path $destFolder $fileName
        $localSrc = if ($localFolder) { Join-Path $localFolder $fileName } else { '' }
        if ((-not $forceOnline) -and $localSrc -and (Test-Path $localSrc)) {
            Copy-Item -Path $localSrc -Destination $dstFile -Force
            return $true
        }
        $url = "$RepoRawBase/${fileName}?t=$CacheBust"
        for ($attempt = 1; $attempt -le 2; $attempt++) {
            try {
                if (-not $wc) { $wc = New-Object System.Net.WebClient }
                $tmp = "$dstFile.download"
                $wc.DownloadFile($url, $tmp)
                if ((Get-Item $tmp).Length -lt 50000) { throw "Downloaded file too small: $fileName" }
                Move-Item -Force $tmp $dstFile
                return $true
            } catch {
                Remove-Item "$dstFile.download" -Force -ErrorAction SilentlyContinue
                if ($attempt -eq 1) { Start-Sleep -Milliseconds 700 }
                elseif (-not $optional) {
                    if ($localSrc -and (Test-Path $localSrc)) {
                        Copy-Item -Path $localSrc -Destination $dstFile -Force
                        return $true
                    }
                    throw
                }
            }
        }
        return $false
    }

    $total = $selectedBins.Count
    for ($idx = 0; $idx -lt $total; $idx++) {
        $bin = $selectedBins[$idx]
        $pct = [int](5 + (($idx + 1) / [Math]::Max(1, $total)) * 85)
        & $onProgress $pct "Installing $bin (.dll + .vst3) [$($idx + 1)/$total]..."
        & $installFile "${bin}.dll"  $localVst2Src $dstVst2 $false | Out-Null
        & $installFile "${bin}.vst3" $localVst3Src $dstVst3 $false | Out-Null
    }

    foreach ($sup in @('onnxruntime.dll', 'onnxruntime_providers_shared.dll')) {
        & $onProgress 93 "Installing runtime dependency: $sup..."
        & $installFile $sup $localVst2Src $dstVst2 $true | Out-Null
        & $installFile $sup $localVst3Src $dstVst3 $true | Out-Null
    }

    $updLocal = Join-Path $SourceDir 'ChromaUpdater.exe'
    if (Test-Path $updLocal) {
        & $onProgress 97 "Installing ChromaUpdater.exe..."
        Copy-Item -Path $updLocal -Destination (Join-Path $dstVst2 'ChromaUpdater.exe') -Force
        Copy-Item -Path $updLocal -Destination (Join-Path $dstVst3 'ChromaUpdater.exe') -Force
    }
    & $onProgress 100 "Installation Complete! ($total plugins synced)"
}

# ---------------------------------------------------------------------------
# Headless / CLI Mode (for scripted installs & automated verification)
# ---------------------------------------------------------------------------
if ($Headless) {
    $isValidExisting = $false; $daysLeft = 0; $masked = ''
    $curStatus = [ChromaLicBridge]::ReadLicenseStatus($activeLicPath, [ref]$isValidExisting, [ref]$daysLeft, [ref]$masked)
    Write-Host "[AUDIT] Existing License: $curStatus"
    Write-Host "[AUDIT] Existing Installs: $(Get-LegacyDetectionSummary $initVst2 $initVst3)"

    if ($Serial) {
        $msg = ''
        $ok = [ChromaLicBridge]::SaveLicense($activeLicPath, $Serial, [ref]$msg)
        if (-not $ok) {
            Write-Error $msg
            exit 2
        }
        Write-Host "[LICENSE] $msg"
    }

    $selBins = if ($PluginsFilter) {
        $wanted = $PluginsFilter.Split(',') | ForEach-Object { $_.Trim().ToLower() }
        @($Plugins | Where-Object { $wanted -contains $_.bin.ToLower() } | ForEach-Object { $_.bin })
    } else {
        @($Plugins | ForEach-Object { $_.bin })
    }

    Perform-Install $initVst2 $initVst3 $selBins ([bool]$PullOnline) {
        param($pct, $text)
        Write-Host ("[{0,3}%] {1}" -f $pct, $text)
    }
    exit 0
}

# ---------------------------------------------------------------------------
# Interactive Dark Carbon / Gunmetal Hardware GUI Wizard
# ---------------------------------------------------------------------------
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$colBg        = [System.Drawing.Color]::FromArgb(11, 15, 22)
$colPanel     = [System.Drawing.Color]::FromArgb(17, 23, 34)
$colHeader    = [System.Drawing.Color]::FromArgb(22, 30, 44)
$colBorder    = [System.Drawing.Color]::FromArgb(42, 56, 78)
$colCyan      = [System.Drawing.Color]::FromArgb(0, 224, 245)
$colGreen     = [System.Drawing.Color]::FromArgb(24, 195, 138)
$colAmber     = [System.Drawing.Color]::FromArgb(242, 165, 38)
$colRed       = [System.Drawing.Color]::FromArgb(239, 78, 86)
$colText      = [System.Drawing.Color]::FromArgb(232, 238, 246)
$colMuted     = [System.Drawing.Color]::FromArgb(142, 158, 180)
$colInputBg   = [System.Drawing.Color]::FromArgb(10, 14, 20)

$fontTitle    = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
$fontSection  = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$fontBody     = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Regular)
$fontMono     = New-Object System.Drawing.Font('Consolas', 9.5, [System.Drawing.FontStyle]::Regular)

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Chroma Audio Suite // All-In-One Installer & Serial Activator'
$form.Size = New-Object System.Drawing.Size(780, 740)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.BackColor = $colBg
$form.ForeColor = $colText

# Header Strip
$pnlHeader = New-Object System.Windows.Forms.Panel
$pnlHeader.SetBounds(0, 0, 780, 62)
$pnlHeader.BackColor = $colHeader
$form.Controls.Add($pnlHeader)

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = 'CHROMA AUDIO SUITE // ALL-IN-ONE INSTALLER'
$lblTitle.Font = $fontTitle
$lblTitle.ForeColor = $colCyan
$lblTitle.SetBounds(20, 10, 560, 26)
$pnlHeader.Controls.Add($lblTitle)

$srcModeTxt = if ($hasLocalZipPayload) { 'Offline Bundle Ready (+ Optional CI/CD Sync)' } else { 'Online CI/CD Cloud Sync' }
$suiteVerTxt = if ($manifest -and $manifest.suite_version) { "v$($manifest.suite_version)" } else { 'Latest' }
$lblSub = New-Object System.Windows.Forms.Label
$lblSub.Text = "Suite Release: $suiteVerTxt   |   Source: $srcModeTxt"
$lblSub.Font = $fontBody
$lblSub.ForeColor = $colMuted
$lblSub.SetBounds(22, 36, 620, 18)
$pnlHeader.Controls.Add($lblSub)

# Panel 1: Serial Key Activation
$pnlLic = New-Object System.Windows.Forms.Panel
$pnlLic.SetBounds(18, 76, 730, 118)
$pnlLic.BackColor = $colPanel
$pnlLic.BorderStyle = 'FixedSingle'
$form.Controls.Add($pnlLic)

$lblLicHdr = New-Object System.Windows.Forms.Label
$lblLicHdr.Text = '1. SERIAL KEY ACTIVATION (UNLOCKS ALL 15 PLUGINS)'
$lblLicHdr.Font = $fontSection
$lblLicHdr.ForeColor = $colCyan
$lblLicHdr.SetBounds(14, 10, 400, 18)
$pnlLic.Controls.Add($lblLicHdr)

$isValidLic = $false; $daysRem = 0; $keyMask = ''
$licStatusText = [ChromaLicBridge]::ReadLicenseStatus($activeLicPath, [ref]$isValidLic, [ref]$daysRem, [ref]$keyMask)

$lblLicState = New-Object System.Windows.Forms.Label
$lblLicState.Text = "Status: $licStatusText"
$lblLicState.Font = $fontBody
$lblLicState.ForeColor = if ($isValidLic) { $colGreen } else { $colAmber }
$lblLicState.SetBounds(390, 10, 326, 18)
$lblLicState.TextAlign = 'TopRight'
$pnlLic.Controls.Add($lblLicState)

$txtSerial = New-Object System.Windows.Forms.TextBox
$txtSerial.Font = $fontMono
$txtSerial.BackColor = $colInputBg
$txtSerial.ForeColor = $colText
$txtSerial.BorderStyle = 'FixedSingle'
$txtSerial.SetBounds(14, 38, 430, 26)
if ($Serial) { $txtSerial.Text = $Serial }
elseif ($isValidLic) { $txtSerial.Text = $keyMask }
$pnlLic.Controls.Add($txtSerial)

$btnCheckKey = New-Object System.Windows.Forms.Button
$btnCheckKey.Text = 'Verify Key'
$btnCheckKey.FlatStyle = 'Flat'
$btnCheckKey.BackColor = [System.Drawing.Color]::FromArgb(24, 38, 56)
$btnCheckKey.ForeColor = $colCyan
$btnCheckKey.FlatAppearance.BorderColor = $colBorder
$btnCheckKey.Font = $fontSection
$btnCheckKey.SetBounds(454, 37, 110, 27)
$pnlLic.Controls.Add($btnCheckKey)

$chkSkipKey = New-Object System.Windows.Forms.CheckBox
$chkSkipKey.Text = 'Skip key (activate in DAW later)'
$chkSkipKey.Font = $fontBody
$chkSkipKey.ForeColor = $colMuted
$chkSkipKey.SetBounds(574, 41, 150, 20)
$chkSkipKey.Checked = $isValidLic
$pnlLic.Controls.Add($chkSkipKey)

$lblLicMsg = New-Object System.Windows.Forms.Label
$lblLicMsg.Text = if ($isValidLic) {
    'Valid machine-locked license already present. Leave as-is or enter a new key to switch.'
} else {
    'Paste your 20-character key (CHRM-XXXX-XXXX-XXXX-XXXX) to activate automatically during install.'
}
$lblLicMsg.Font = $fontBody
$lblLicMsg.ForeColor = $colMuted
$lblLicMsg.SetBounds(14, 74, 700, 34)
$pnlLic.Controls.Add($lblLicMsg)

# Panel 2: Folder Detection & Custom Selection
$pnlDir = New-Object System.Windows.Forms.Panel
$pnlDir.SetBounds(18, 206, 730, 126)
$pnlDir.BackColor = $colPanel
$pnlDir.BorderStyle = 'FixedSingle'
$form.Controls.Add($pnlDir)

$lblDirHdr = New-Object System.Windows.Forms.Label
$lblDirHdr.Text = '2. VST2 / VST3 INSTALL FOLDERS & SYSTEM DETECTION'
$lblDirHdr.Font = $fontSection
$lblDirHdr.ForeColor = $colCyan
$lblDirHdr.SetBounds(14, 10, 480, 18)
$pnlDir.Controls.Add($lblDirHdr)

$lblDetectNote = New-Object System.Windows.Forms.Label
$lblDetectNote.Text = Get-LegacyDetectionSummary $initVst2 $initVst3
$lblDetectNote.Font = $fontBody
$lblDetectNote.ForeColor = $colAmber
$lblDetectNote.SetBounds(14, 98, 700, 20)
$pnlDir.Controls.Add($lblDetectNote)

$lblV2 = New-Object System.Windows.Forms.Label
$lblV2.Text = 'VST2 (.dll):'
$lblV2.Font = $fontBody
$lblV2.ForeColor = $colText
$lblV2.SetBounds(14, 38, 86, 20)
$pnlDir.Controls.Add($lblV2)

$txtVst2 = New-Object System.Windows.Forms.TextBox
$txtVst2.Text = $initVst2
$txtVst2.Font = $fontBody
$txtVst2.BackColor = $colInputBg
$txtVst2.ForeColor = $colText
$txtVst2.BorderStyle = 'FixedSingle'
$txtVst2.SetBounds(104, 36, 514, 24)
$pnlDir.Controls.Add($txtVst2)

$btnBrowse2 = New-Object System.Windows.Forms.Button
$btnBrowse2.Text = 'Browse...'
$btnBrowse2.FlatStyle = 'Flat'
$btnBrowse2.BackColor = [System.Drawing.Color]::FromArgb(24, 38, 56)
$btnBrowse2.ForeColor = $colText
$btnBrowse2.FlatAppearance.BorderColor = $colBorder
$btnBrowse2.SetBounds(626, 35, 88, 25)
$pnlDir.Controls.Add($btnBrowse2)

$lblV3 = New-Object System.Windows.Forms.Label
$lblV3.Text = 'VST3 (.vst3):'
$lblV3.Font = $fontBody
$lblV3.ForeColor = $colText
$lblV3.SetBounds(14, 68, 86, 20)
$pnlDir.Controls.Add($lblV3)

$txtVst3 = New-Object System.Windows.Forms.TextBox
$txtVst3.Text = $initVst3
$txtVst3.Font = $fontBody
$txtVst3.BackColor = $colInputBg
$txtVst3.ForeColor = $colText
$txtVst3.BorderStyle = 'FixedSingle'
$txtVst3.SetBounds(104, 66, 514, 24)
$pnlDir.Controls.Add($txtVst3)

$btnBrowse3 = New-Object System.Windows.Forms.Button
$btnBrowse3.Text = 'Browse...'
$btnBrowse3.FlatStyle = 'Flat'
$btnBrowse3.BackColor = [System.Drawing.Color]::FromArgb(24, 38, 56)
$btnBrowse3.ForeColor = $colText
$btnBrowse3.FlatAppearance.BorderColor = $colBorder
$btnBrowse3.SetBounds(626, 65, 88, 25)
$pnlDir.Controls.Add($btnBrowse3)

# Panel 3: Detected Plugin Inventory & Picker
$pnlPlugs = New-Object System.Windows.Forms.Panel
$pnlPlugs.SetBounds(18, 344, 730, 260)
$pnlPlugs.BackColor = $colPanel
$pnlPlugs.BorderStyle = 'FixedSingle'
$form.Controls.Add($pnlPlugs)

$lblPlugHdr = New-Object System.Windows.Forms.Label
$lblPlugHdr.Text = '3. SUITE INVENTORY (15 PLUGINS)'
$lblPlugHdr.Font = $fontSection
$lblPlugHdr.ForeColor = $colCyan
$lblPlugHdr.SetBounds(14, 10, 300, 18)
$pnlPlugs.Controls.Add($lblPlugHdr)

$chkOnlinePull = New-Object System.Windows.Forms.CheckBox
$chkOnlinePull.Text = 'Fetch latest from CI/CD instead of local ZIP'
$chkOnlinePull.Font = $fontBody
$chkOnlinePull.ForeColor = $colMuted
$chkOnlinePull.SetBounds(320, 8, 270, 20)
$chkOnlinePull.Checked = (-not $hasLocalZipPayload) -or [bool]$PullOnline
$chkOnlinePull.Enabled = $hasLocalZipPayload
$pnlPlugs.Controls.Add($chkOnlinePull)

$btnSelAll = New-Object System.Windows.Forms.Button
$btnSelAll.Text = 'All 15'
$btnSelAll.FlatStyle = 'Flat'
$btnSelAll.BackColor = [System.Drawing.Color]::FromArgb(24, 38, 56)
$btnSelAll.ForeColor = $colText
$btnSelAll.FlatAppearance.BorderColor = $colBorder
$btnSelAll.SetBounds(598, 7, 56, 22)
$pnlPlugs.Controls.Add($btnSelAll)

$btnSelMissing = New-Object System.Windows.Forms.Button
$btnSelMissing.Text = 'Missing'
$btnSelMissing.FlatStyle = 'Flat'
$btnSelMissing.BackColor = [System.Drawing.Color]::FromArgb(24, 38, 56)
$btnSelMissing.ForeColor = $colText
$btnSelMissing.FlatAppearance.BorderColor = $colBorder
$btnSelMissing.SetBounds(658, 7, 58, 22)
$pnlPlugs.Controls.Add($btnSelMissing)

$lvPlugs = New-Object System.Windows.Forms.ListView
$lvPlugs.SetBounds(14, 34, 700, 214)
$lvPlugs.View = 'Details'
$lvPlugs.FullRowSelect = $true
$lvPlugs.CheckBoxes = $true
$lvPlugs.GridLines = $false
$lvPlugs.BackColor = $colInputBg
$lvPlugs.ForeColor = $colText
$lvPlugs.BorderStyle = 'FixedSingle'
[void]$lvPlugs.Columns.Add('Plugin', 175)
[void]$lvPlugs.Columns.Add('Category', 145)
[void]$lvPlugs.Columns.Add('Release', 90)
[void]$lvPlugs.Columns.Add('Current System Status', 270)
$pnlPlugs.Controls.Add($lvPlugs)

$refreshGrid = {
    $v2 = $txtVst2.Text.Trim()
    $v3 = $txtVst3.Text.Trim()
    $lblDetectNote.Text = Get-LegacyDetectionSummary $v2 $v3
    $lvPlugs.BeginUpdate()
    $lvPlugs.Items.Clear()
    foreach ($p in $Plugins) {
        $has2 = if ($v2) { Test-Path (Join-Path $v2 "$($p.bin).dll") } else { $false }
        $has3 = if ($v3) { Test-Path (Join-Path $v3 "$($p.bin).vst3") } else { $false }
        $hasLegacyCore = ($p.bin -eq 'ChromaCoreVST') -and ((Test-Path (Join-Path $v2 'ChromaCorePro.dll')) -or (Test-Path (Join-Path $v3 'ChromaCorePro.vst3')))
        $statusTxt = if ($hasLegacyCore) {
            'LEGACY ChromaCorePro -> UPGRADE'
        } elseif ($has2 -and $has3) {
            'INSTALLED (VST2 + VST3 -> UPDATE READY)'
        } elseif ($has2 -or $has3) {
            'PARTIAL INSTALL -> REPAIR / SYNC'
        } else {
            'NOT INSTALLED -> FRESH INSTALL'
        }
        $ver = if ($manifest -and $manifest.plugins.($p.key)) { "v$($manifest.plugins.($p.key).version)" } else { 'latest' }
        $item = New-Object System.Windows.Forms.ListViewItem($p.bin)
        $item.Checked = $true
        $item.Tag = $p.bin
        [void]$item.SubItems.Add($p.cat)
        [void]$item.SubItems.Add($ver)
        [void]$item.SubItems.Add($statusTxt)
        if ($statusTxt -like 'NOT INSTALLED*') { $item.ForeColor = $colAmber }
        elseif ($statusTxt -like 'PARTIAL*' -or $statusTxt -like 'LEGACY*') { $item.ForeColor = $colCyan }
        else { $item.ForeColor = $colGreen }
        [void]$lvPlugs.Items.Add($item)
    }
    $lvPlugs.EndUpdate()
}
& $refreshGrid

# Footer Progress & Install Button
$progress = New-Object System.Windows.Forms.ProgressBar
$progress.SetBounds(18, 616, 520, 18)
$progress.Minimum = 0
$progress.Maximum = 100
$form.Controls.Add($progress)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = 'Ready to install.'
$lblStatus.Font = $fontBody
$lblStatus.ForeColor = $colMuted
$lblStatus.SetBounds(18, 640, 520, 22)
$form.Controls.Add($lblStatus)

$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Text = 'INSTALL & ACTIVATE'
$btnInstall.Font = $fontSection
$btnInstall.FlatStyle = 'Flat'
$btnInstall.BackColor = $colGreen
$btnInstall.ForeColor = [System.Drawing.Color]::FromArgb(8, 12, 18)
$btnInstall.FlatAppearance.BorderSize = 0
$btnInstall.SetBounds(554, 616, 194, 44)
$form.Controls.Add($btnInstall)

# Event Wiring
$btnBrowse2.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Select your VST2 (.dll) plugin folder'
    if (Test-Path $txtVst2.Text) { $dlg.SelectedPath = $txtVst2.Text }
    if ($dlg.ShowDialog() -eq 'OK' -and $dlg.SelectedPath) {
        $txtVst2.Text = $dlg.SelectedPath
        & $refreshGrid
    }
})
$btnBrowse3.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Select your VST3 (.vst3) plugin folder'
    if (Test-Path $txtVst3.Text) { $dlg.SelectedPath = $txtVst3.Text }
    if ($dlg.ShowDialog() -eq 'OK' -and $dlg.SelectedPath) {
        $txtVst3.Text = $dlg.SelectedPath
        & $refreshGrid
    }
})
$txtVst2.Add_Leave($refreshGrid)
$txtVst3.Add_Leave($refreshGrid)

$btnSelAll.Add_Click({
    foreach ($it in $lvPlugs.Items) { $it.Checked = $true }
})
$btnSelMissing.Add_Click({
    foreach ($it in $lvPlugs.Items) { $it.Checked = ($it.SubItems[3].Text -notlike 'INSTALLED*') }
})

$btnCheckKey.Add_Click({
    $raw = $txtSerial.Text.Trim()
    if (-not $raw -or $raw.Contains('*')) {
        $lblLicMsg.ForeColor = $colAmber
        $lblLicMsg.Text = if ($isValidLic) { "Existing active key ($keyMask) is already verified on this PC." } else { 'Please paste your 20-character serial key first.' }
        return
    }
    $clean = ''
    if ([ChromaLicBridge]::IsValidActiveKey($raw, [ref]$clean)) {
        $txtSerial.Text = $clean
        $lblLicMsg.ForeColor = $colGreen
        $lblLicMsg.Text = "Key recognized ($clean)! Click INSTALL & ACTIVATE to save hardware license & install plugins."
    } else {
        $lblLicMsg.ForeColor = $colRed
        $lblLicMsg.Text = 'Invalid or retired serial key. Double-check your key or check Skip Key to activate inside the DAW.'
    }
})

$btnInstall.Add_Click({
    $checked = @($lvPlugs.Items | Where-Object { $_.Checked } | ForEach-Object { [string]$_.Tag })
    if ($checked.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Please select at least one plugin to install.', 'Chroma Audio Suite', 'OK', 'Warning') | Out-Null
        return
    }

    # Check if a host DAW holds VST files open
    $daws = @('Ableton Live 10 Suite', 'Ableton Live 11 Suite', 'Ableton Live 12 Suite', 'Live', 'FL64', 'FL', 'reaper', 'Bitwig Studio', 'Cubase', 'Studio One')
    $openDaws = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $n = $_.ProcessName; ($daws | Where-Object { $n -ieq $_ }).Count -gt 0 } | Select-Object -ExpandProperty ProcessName -Unique)
    if ($openDaws.Count -gt 0) {
        $ans = [System.Windows.Forms.MessageBox]::Show(
            "Open DAW detected: $($openDaws -join ', ').`nClose your DAW so VST files aren't locked, or click OK to retry anyway.",
            'DAW Running', 'OKCancel', 'Warning')
        if ($ans -eq 'Cancel') { return }
    }

    # Activate Serial if entered (required unless Skip Key checked or already validly licensed)
    $enteredRaw = $txtSerial.Text.Trim()
    $shouldWriteNewKey = ($enteredRaw.Length -gt 0) -and (-not $enteredRaw.Contains('*'))
    if (-not $chkSkipKey.Checked -and -not $isValidLic -and -not $shouldWriteNewKey) {
        [System.Windows.Forms.MessageBox]::Show(
            "Please enter your serial key (CHRM-XXXX-XXXX-XXXX-XXXX) or check 'Skip key' to activate inside the DAW.",
            'Serial Key Required', 'OK', 'Information') | Out-Null
        $txtSerial.Focus()
        return
    }

    if ($shouldWriteNewKey -and -not $chkSkipKey.Checked) {
        $licMsg = ''
        $okLic = [ChromaLicBridge]::SaveLicense($activeLicPath, $enteredRaw, [ref]$licMsg)
        if (-not $okLic) {
            $lblLicMsg.ForeColor = $colRed
            $lblLicMsg.Text = $licMsg
            [System.Windows.Forms.MessageBox]::Show($licMsg, 'Serial Verification Failed', 'OK', 'Error') | Out-Null
            return
        }
        $lblLicMsg.ForeColor = $colGreen
        $lblLicMsg.Text = $licMsg
        $lblLicState.ForeColor = $colGreen
        $lblLicState.Text = 'Status: ACTIVE (30d)'
    }

    $btnInstall.Enabled = $false
    try {
        Perform-Install $txtVst2.Text.Trim() $txtVst3.Text.Trim() $checked ([bool]$chkOnlinePull.Checked) {
            param($pct, $txt)
            $progress.Value = [Math]::Min(100, [Math]::Max(0, $pct))
            $lblStatus.ForeColor = $colCyan
            $lblStatus.Text = $txt
            [System.Windows.Forms.Application]::DoEvents()
        }
        $lblStatus.ForeColor = $colGreen
        & $refreshGrid
        [System.Windows.Forms.MessageBox]::Show(
            "Chroma Audio Suite installation complete!`n`nVST2: $($txtVst2.Text.Trim())`nVST3: $($txtVst3.Text.Trim())`n`nOpen your DAW and rescan plugins.",
            'Installation Complete', 'OK', 'Information') | Out-Null
    } catch {
        $lblStatus.ForeColor = $colRed
        $lblStatus.Text = "Error: $($_.Exception.Message)"
        [System.Windows.Forms.MessageBox]::Show("Installation error:`n$($_.Exception.Message)", 'Chroma Installer Error', 'OK', 'Error') | Out-Null
    } finally {
        $btnInstall.Enabled = $true
    }
})

[void]$form.ShowDialog()
