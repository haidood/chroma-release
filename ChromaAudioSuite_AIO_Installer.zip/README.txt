================================================================
  CHROMA AUDIO SUITE -- ALL-IN-ONE INSTALLER (ALL 15 PLUGINS)
================================================================

1. Extract ALL files from this ZIP to a temporary folder.
2. Double-click:  Install_Chroma_Suite.bat
   - Prompts for your 20-character Serial Key (CHRM-XXXX-XXXX-XXXX-XXXX)
     or detects an existing active license automatically.
   - Scans your system for existing Chroma plugins and lets you browse
     to custom VST2 (.dll) and VST3 (.vst3) folders.
   - Auto-migrates legacy VstPlugins\Dev and upgrades ChromaCorePro -> ChromaCoreVST.
3. Open your DAW and rescan VST2/VST3 plugins.

Third-party software: onnxruntime (MIT License, Microsoft Corporation).
See THIRD_PARTY_NOTICES\onnxruntime for its licence and notices.
