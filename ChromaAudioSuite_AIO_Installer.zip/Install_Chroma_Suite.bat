@echo off
cd /d "%~dp0"
title Chroma Audio Suite - All-In-One Installer
powershell -STA -NoProfile -ExecutionPolicy Bypass -File "%~dp0Chroma_Suite_AIO_Installer.ps1"
